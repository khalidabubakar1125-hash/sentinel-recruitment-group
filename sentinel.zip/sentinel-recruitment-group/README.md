# Sentinel Recruitment Group Website

## Run locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push this folder to GitHub.
2. Go to Vercel.
3. Click Add New -> Project.
4. Import this GitHub repo.
5. Click Deploy.

## Google Sheets hookup

Open `app/page.js` and paste your Google Apps Script web app URL into:

- `GOOGLE_SCRIPT_URL_CONTACT`
- `GOOGLE_SCRIPT_URL_APPLICATION`

You can use the same URL for both.
