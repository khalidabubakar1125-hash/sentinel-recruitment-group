"use client";

import { useMemo, useState } from "react";

const GOOGLE_SCRIPT_URL_CONTACT = "";
const GOOGLE_SCRIPT_URL_APPLICATION = "";

const jobs = [
  {
    title: "Office Cleaner",
    pay: "£12–£14 per hour",
    type: "Cleaning",
    location: "Manchester",
    description: "Reliable office cleaning opportunities across Manchester commercial sites."
  },
  {
    title: "Hotel Housekeeper",
    pay: "£12–£15 per hour",
    type: "Cleaning",
    location: "Manchester",
    description: "Housekeeping roles with trusted hospitality clients in Manchester."
  },
  {
    title: "Commercial Cleaner",
    pay: "£12–£14 per hour",
    type: "Cleaning",
    location: "Manchester",
    description: "Commercial cleaning roles for dependable candidates ready to work."
  },
  {
    title: "School Cleaner",
    pay: "£11.50–£13 per hour",
    type: "Cleaning",
    location: "Manchester",
    description: "School cleaning positions for organised and punctual staff."
  },
  {
    title: "SIA Security Guard",
    pay: "£13–£17 per hour",
    type: "Security",
    location: "Manchester",
    description: "Security roles for SIA licensed professionals across Manchester."
  },
  {
    title: "Front of House Security",
    pay: "£13–£16 per hour",
    type: "Security",
    location: "Manchester",
    description: "Professional front of house security roles with client-facing duties."
  },
  {
    title: "Retail Security Officer",
    pay: "£13–£15 per hour",
    type: "Security",
    location: "Manchester",
    description: "Retail security opportunities requiring strong presence and reliability."
  },
  {
    title: "Static Security Officer",
    pay: "£13–£16 per hour",
    type: "Security",
    location: "Manchester",
    description: "Static guarding roles for dependable security staff."
  }
];

export default function HomePage() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [jobFilter, setJobFilter] = useState("All");
  const [selectedJob, setSelectedJob] = useState("");

  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    company: "",
    message: ""
  });

  const [applyForm, setApplyForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    cvLink: ""
  });

  const [contactErrors, setContactErrors] = useState({});
  const [applyErrors, setApplyErrors] = useState({});
  const [contactSuccess, setContactSuccess] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);

  const filteredJobs = useMemo(() => {
    if (jobFilter === "All") return jobs;
    return jobs.filter((job) => job.type === jobFilter);
  }, [jobFilter]);

  const chooseJob = (title) => {
    setSelectedJob(title);
    setApplySuccess(false);
    setApplyErrors({});
    const el = document.getElementById("apply");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const handleContactChange = (field, value) => {
    setContactForm((prev) => ({ ...prev, [field]: value }));
    setContactErrors((prev) => ({ ...prev, [field]: "", submit: "" }));
  };

  const handleApplyChange = (field, value) => {
    setApplyForm((prev) => ({ ...prev, [field]: value }));
    setApplyErrors((prev) => ({ ...prev, [field]: "", submit: "" }));
  };

  const validateContact = () => {
    const errors = {};
    if (!contactForm.name.trim()) errors.name = "Please enter your name.";
    if (!contactForm.email.trim()) errors.email = "Please enter your email.";
    if (contactForm.email && !contactForm.email.includes("@")) errors.email = "Please enter a valid email.";
    if (!contactForm.company.trim()) errors.company = "Please enter your company.";
    if (!contactForm.message.trim()) errors.message = "Please enter your message.";
    return errors;
  };

  const validateApply = () => {
    const errors = {};
    if (!selectedJob) errors.selectedJob = "Please choose a role.";
    if (!applyForm.fullName.trim()) errors.fullName = "Please enter your full name.";
    if (!applyForm.email.trim()) errors.email = "Please enter your email.";
    if (applyForm.email && !applyForm.email.includes("@")) errors.email = "Please enter a valid email.";
    if (!applyForm.phone.trim()) errors.phone = "Please enter your phone number.";
    return errors;
  };

  const handleContactSubmit = async (e) => {
    e.preventDefault();
    const errors = validateContact();
    setContactErrors(errors);
    if (Object.keys(errors).length) return;

    try {
      if (GOOGLE_SCRIPT_URL_CONTACT) {
        await fetch(GOOGLE_SCRIPT_URL_CONTACT, {
          method: "POST",
          mode: "no-cors",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            submittedAt: new Date().toISOString(),
            formType: "client_enquiry",
            ...contactForm
          })
        });
      }

      setContactSuccess(true);
      setContactForm({ name: "", email: "", company: "", message: "" });
    } catch (error) {
      setContactErrors({ submit: "There was a problem sending your enquiry." });
    }
  };

  const handleApplySubmit = async (e) => {
    e.preventDefault();
    const errors = validateApply();
    setApplyErrors(errors);
    if (Object.keys(errors).length) return;

    try {
      if (GOOGLE_SCRIPT_URL_APPLICATION) {
        await fetch(GOOGLE_SCRIPT_URL_APPLICATION, {
          method: "POST",
          mode: "no-cors",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            submittedAt: new Date().toISOString(),
            formType: "candidate_application",
            selectedJob,
            ...applyForm
          })
        });
      }

      setApplySuccess(true);
      setApplyForm({ fullName: "", email: "", phone: "", cvLink: "" });
    } catch (error) {
      setApplyErrors({ submit: "There was a problem sending your application." });
    }
  };

  return (
    <>
      <header className="topbar">
        <div className="container topbar-inner">
          <div>
            <div className="brand-main">SENTINEL</div>
            <div className="brand-sub">Recruitment Group</div>
          </div>

          <nav className="nav">
            <a href="#services">Services</a>
            <a href="#about">About</a>
            <a href="#jobs">Jobs</a>
            <a href="#contact">Contact</a>
          </nav>

          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <button className="menu-btn" onClick={() => setMobileOpen(!mobileOpen)}>
              Menu
            </button>
            <a className="cta-btn" href="#contact">Hire Staff</a>
          </div>
        </div>

        {mobileOpen && (
          <div className="container" style={{ paddingBottom: 16 }}>
            <div style={{ display: "grid", gap: 12, fontFamily: "Arial, Helvetica, sans-serif", fontWeight: 700 }}>
              <a href="#services" onClick={() => setMobileOpen(false)}>Services</a>
              <a href="#about" onClick={() => setMobileOpen(false)}>About</a>
              <a href="#jobs" onClick={() => setMobileOpen(false)}>Jobs</a>
              <a href="#contact" onClick={() => setMobileOpen(false)}>Contact</a>
            </div>
          </div>
        )}
      </header>

      <main>
        <section className="hero">
          <div className="container hero-grid">
            <div>
              <span className="badge">Trusted staffing support for cleaning and security in Manchester</span>
              <h1>Reliable staff. Professional service. Fast delivery.</h1>
              <p>
                Sentinel Recruitment Group helps businesses hire dependable cleaning
                and security staff while giving candidates a simple way to apply for
                live Manchester roles.
              </p>

              <div className="hero-actions">
                <a className="cta-btn" href="#contact">Request Staff</a>
                <a className="secondary-btn" href="#jobs">View Jobs</a>
              </div>

              <div className="stats">
                <div className="stat">
                  <strong>Manchester</strong>
                  <span>Current job focus</span>
                </div>
                <div className="stat">
                  <strong>Cleaning</strong>
                  <span>Essential staffing</span>
                </div>
                <div className="stat">
                  <strong>Security</strong>
                  <span>Professional support</span>
                </div>
              </div>
            </div>

            <div className="hero-cards">
              <div className="card-dark">
                <span className="small-label">Employers</span>
                <h3>Need staff quickly?</h3>
                <p className="dark-muted">
                  We support businesses that need reliable cleaning and security staff
                  with a straightforward enquiry process.
                </p>
                <div className="most-requested">
                  <div className="quick-pill">Office cleaners</div>
                  <div className="quick-pill">Hotel housekeeping</div>
                  <div className="quick-pill">SIA security guards</div>
                </div>
              </div>

              <div className="card-white">
                <span className="small-label">Candidates</span>
                <h3>Looking for work?</h3>
                <p className="muted">
                  Apply for current Manchester cleaning and security jobs through the
                  job list below.
                </p>
                <div className="job-list-quick">
                  {jobs.slice(0, 4).map((job) => (
                    <button key={job.title} className="quick-job" onClick={() => chooseJob(job.title)}>
                      {job.title} - {job.location}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="services">
          <div className="container">
            <div className="section-intro">
              <span className="small-label" style={{ color: "#666" }}>Our services</span>
              <h2>Focused staffing for essential roles</h2>
              <p>
                Sentinel Recruitment Group supports employers with dependable
                cleaning and security recruitment across Manchester.
              </p>
            </div>

            <div className="services-grid">
              <div className="panel">
                <h3>Cleaning Staff</h3>
                <div className="panel-list">
                  <div>Office cleaners</div>
                  <div>Commercial cleaners</div>
                  <div>Hotel housekeeping</div>
                  <div>Temporary and permanent roles</div>
                </div>
              </div>

              <div className="panel">
                <h3>Security Staff</h3>
                <div className="panel-list">
                  <div>SIA licensed guards</div>
                  <div>Static security</div>
                  <div>Front of house security</div>
                  <div>Temporary and permanent roles</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="about" style={{ background: "#fff" }}>
          <div className="container two-col-grid">
            <div>
              <span className="small-label" style={{ color: "#666" }}>Who we are</span>
              <h2>A recruitment partner built around reliability</h2>
              <p className="muted" style={{ fontSize: 18 }}>
                Sentinel Recruitment Group is a modern staffing business focused on
                dependable people, fast response times, and straightforward service
                for employers and candidates.
              </p>
            </div>

            <div className="reasons-grid">
              {[
                "Fast response times",
                "Reliable, vetted candidates",
                "Professional communication",
                "Manchester job focus",
                "Cleaning and security specialists",
                "Simple hiring support"
              ].map((item) => (
                <div className="reason-box" key={item}>{item}</div>
              ))}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="section-intro">
              <span className="small-label" style={{ color: "#666" }}>How it works</span>
              <h2>Simple hiring process</h2>
            </div>

            <div className="steps-grid">
              <div className="panel">
                <div className="step-number">1</div>
                <h3>Tell us what you need</h3>
                <p className="muted">Share the role, site, and timing.</p>
              </div>
              <div className="panel">
                <div className="step-number">2</div>
                <h3>We source and screen</h3>
                <p className="muted">We identify suitable candidates quickly.</p>
              </div>
              <div className="panel">
                <div className="step-number">3</div>
                <h3>Ready to start</h3>
                <p className="muted">You receive staff ready to move forward.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="section jobs-section" id="jobs">
          <div className="container">
            <div className="jobs-header">
              <div>
                <span className="small-label" style={{ color: "#bbb" }}>Current roles</span>
                <h2>Manchester jobs</h2>
              </div>

              <div className="filters">
                {["All", "Cleaning", "Security"].map((filter) => (
                  <button
                    key={filter}
                    className={`filter-btn ${jobFilter === filter ? "active" : ""}`}
                    onClick={() => setJobFilter(filter)}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            <div className="jobs-grid">
              {filteredJobs.map((job) => (
                <div className="job-card" key={job.title}>
                  <h3>{job.title}</h3>
                  <div className="job-meta">{job.pay}</div>
                  <div className="job-meta">{job.location}</div>
                  <p>{job.description}</p>
                  <button className="job-btn" onClick={() => chooseJob(job.title)}>
                    Apply Now
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="apply">
          <div className="container form-wrap">
            <div className="info-panel">
              <span className="small-label" style={{ color: "#666" }}>Candidate application</span>
              <h3>Apply for a role</h3>
              <p>
                Choose a job, enter your details, and submit your application.
                The selected role dropdown includes all current Manchester jobs.
              </p>
              {applySuccess && (
                <div className="success">
                  Application submitted. Connect your Google Apps Script URL to make this live.
                </div>
              )}
            </div>

            <form className="form-panel" onSubmit={handleApplySubmit}>
              <div className="form-grid two">
                <div style={{ gridColumn: "1 / -1" }}>
                  <select
                    className="select"
                    value={selectedJob}
                    onChange={(e) => {
                      setSelectedJob(e.target.value);
                      setApplyErrors((prev) => ({ ...prev, selectedJob: "" }));
                    }}
                  >
                    <option value="">Choose a role</option>
                    {jobs.map((job) => (
                      <option key={job.title} value={job.title}>
                        {job.title} - {job.location}
                      </option>
                    ))}
                  </select>
                  {applyErrors.selectedJob && <div className="error">{applyErrors.selectedJob}</div>}
                  {applyErrors.submit && <div className="error">{applyErrors.submit}</div>}
                </div>

                <div>
                  <input
                    className="input"
                    placeholder="Full name"
                    value={applyForm.fullName}
                    onChange={(e) => handleApplyChange("fullName", e.target.value)}
                  />
                  {applyErrors.fullName && <div className="error">{applyErrors.fullName}</div>}
                </div>

                <div>
                  <input
                    className="input"
                    placeholder="Email address"
                    value={applyForm.email}
                    onChange={(e) => handleApplyChange("email", e.target.value)}
                  />
                  {applyErrors.email && <div className="error">{applyErrors.email}</div>}
                </div>

                <div>
                  <input
                    className="input"
                    placeholder="Phone number"
                    value={applyForm.phone}
                    onChange={(e) => handleApplyChange("phone", e.target.value)}
                  />
                  {applyErrors.phone && <div className="error">{applyErrors.phone}</div>}
                </div>

                <div>
                  <input
                    className="input"
                    placeholder="CV link (optional)"
                    value={applyForm.cvLink}
                    onChange={(e) => handleApplyChange("cvLink", e.target.value)}
                  />
                </div>
              </div>

              <button className="form-btn" type="submit">Submit Application</button>
            </form>
          </div>
        </section>

        <section className="section" id="contact">
          <div className="container form-wrap">
            <form className="form-panel" onSubmit={handleContactSubmit}>
              <span className="small-label" style={{ color: "#ccc" }}>Get in touch</span>
              <h3>Let’s help you hire with confidence</h3>
              <p className="dark-muted">
                Sentinel Recruitment Group supports employers and candidates across Manchester.
              </p>

              {contactSuccess && (
                <div className="success">
                  Enquiry submitted. Connect your Google Apps Script URL to make this live.
                </div>
              )}

              <div className="form-grid two" style={{ marginTop: 18 }}>
                <div>
                  <input
                    className="input"
                    placeholder="Your name"
                    value={contactForm.name}
                    onChange={(e) => handleContactChange("name", e.target.value)}
                  />
                  {contactErrors.name && <div className="error">{contactErrors.name}</div>}
                </div>

                <div>
                  <input
                    className="input"
                    placeholder="Your email"
                    value={contactForm.email}
                    onChange={(e) => handleContactChange("email", e.target.value)}
                  />
                  {contactErrors.email && <div className="error">{contactErrors.email}</div>}
                </div>

                <div style={{ gridColumn: "1 / -1" }}>
                  <input
                    className="input"
                    placeholder="Company or role type"
                    value={contactForm.company}
                    onChange={(e) => handleContactChange("company", e.target.value)}
                  />
                  {contactErrors.company && <div className="error">{contactErrors.company}</div>}
                </div>

                <div style={{ gridColumn: "1 / -1" }}>
                  <textarea
                    className="textarea"
                    placeholder="Tell us what you need"
                    value={contactForm.message}
                    onChange={(e) => handleContactChange("message", e.target.value)}
                  />
                  {contactErrors.message && <div className="error">{contactErrors.message}</div>}
                  {contactErrors.submit && <div className="error">{contactErrors.submit}</div>}
                </div>
              </div>

              <button className="form-btn" type="submit">Send Enquiry</button>
            </form>

            <div className="info-panel">
              <span className="small-label" style={{ color: "#666" }}>Contact details</span>
              <h3>Sentinel Recruitment Group</h3>
              <p><strong>Email:</strong> info@sentinelrecruitmentgroup.com</p>
              <p><strong>Domain:</strong> sentinelrecruitmentgroup.com</p>
              <p><strong>Location focus:</strong> Manchester</p>
              <p>
                To make the forms fully live, paste your Google Apps Script web app URL
                into the two constants at the top of this file.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-inner">
          <div>© 2026 Sentinel Recruitment Group</div>
          <div>sentinelrecruitmentgroup.com</div>
          <div>info@sentinelrecruitmentgroup.com</div>
        </div>
      </footer>
    </>
  );
}
