import "./globals.css";

export const metadata = {
  title: "Sentinel Recruitment Group",
  description: "Cleaning and security recruitment in Manchester.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
